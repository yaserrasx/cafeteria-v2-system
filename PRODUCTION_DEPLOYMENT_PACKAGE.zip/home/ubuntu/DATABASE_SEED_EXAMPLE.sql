-- Example SQL for seeding initial data into CAFETERIA V2
-- This script assumes the schema has already been applied to your PostgreSQL database.

-- Insert a sample user (Owner/Admin)
INSERT INTO users (id, "openId", name, email, "loginMethod", role, "createdAt", "updatedAt", "lastSignedIn")
VALUES (
    1,
    'google-oauth2|123456789012345678901',
    'Admin User',
    'admin@example.com',
    'google',
    'admin',
    NOW(),
    NOW(),
    NOW()
);

-- Insert a sample marketer
INSERT INTO marketers (id, name, email, "parentId", "isRoot", "referenceCode", country, currency, "createdAt")
VALUES (
    'marketer-123',
    'Global Marketer',
    'marketer@example.com',
    NULL,
    TRUE,
    'GM001',
    'US',
    'USD',
    NOW()
);

-- Insert a sample cafeteria
INSERT INTO cafeterias (id, "marketerId", name, location, "pointsBalance", "graceMode", "referenceCode", country, currency, "createdAt")
VALUES (
    'cafeteria-456',
    'marketer-123',
    'Downtown Cafe',
    '123 Main St, Anytown',
    '1000.00',
    FALSE,
    'DC001',
    'US',
    'USD',
    NOW()
);

-- Insert a sample staff member (Manager)
INSERT INTO "cafeteriaStaff" (id, "cafeteriaId", "userId", name, role, status, "canLogin", "createdAt")
VALUES (
    'staff-789',
    'cafeteria-456',
    1, -- Link to the admin user for simplicity, in real scenario this would be a separate user
    'Jane Manager',
    'manager',
    'active',
    TRUE,
    NOW()
);

-- Insert a sample menu category
INSERT INTO "menuCategories" (id, "cafeteriaId", name, "displayOrder", "createdAt")
VALUES (
    'category-101',
    'cafeteria-456',
    'Beverages',
    1,
    NOW()
);

-- Insert a sample menu item
INSERT INTO "menuItems" (id, "cafeteriaId", "categoryId", name, description, price, available, "createdAt")
VALUES (
    'item-202',
    'cafeteria-456',
    'category-101',
    'Coffee',
    'Freshly brewed coffee',
    '2.50',
    TRUE,
    NOW()
);

-- Insert a sample section
INSERT INTO sections (id, "cafeteriaId", name, "displayOrder", "createdAt")
VALUES (
    'section-A',
    'cafeteria-456',
    'Main Dining',
    1,
    NOW()
);

-- Insert a sample table
INSERT INTO "cafeteriaTables" (id, "cafeteriaId", "sectionId", "tableNumber", capacity, status, "createdAt")
VALUES (
    'table-001',
    'cafeteria-456',
    'section-A',
    1,
    4,
    'available',
    NOW()
);

-- Note: For a full production setup, you would typically have more extensive seed data
-- and potentially separate scripts for different environments (development, testing, production).
