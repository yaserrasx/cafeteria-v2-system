# CAFETERIA V2 - SQL Migration Execution Order

## Overview

This document outlines the recommended order for executing SQL migration scripts to ensure the CAFETERIA V2 database schema is correctly applied and updated. The project uses Drizzle ORM, which generates SQL migration files to track schema changes. For production deployment, these migrations should be applied sequentially.

## Migration Files

All SQL migration files are located in the `drizzle/` directory of the project. They are named with a timestamp prefix (e.g., `0000_uneven_robbie_robertson.sql`) to indicate their chronological order.

## Execution Order

To apply the database schema, execute the SQL files in the `drizzle/` directory in ascending order of their timestamp prefixes. For example, if you have the following files:

- `drizzle/0000_uneven_robbie_robertson.sql`
- `drizzle/0001_numerous_virginia_dare.sql`
- `drizzle/0002_supreme_famine.sql`

You should execute them in this order:

1.  `0000_uneven_robbie_robertson.sql`
2.  `0001_numerous_virginia_dare.sql`
3.  `0002_supreme_famine.sql`

### Steps for Manual Execution (e.g., via Supabase SQL Editor)

1.  **Access your Database:** Log in to your Supabase project and navigate to the **"SQL Editor"**.
2.  **Open Migration File:** Open the first SQL migration file (e.g., `0000_uneven_robbie_robertson.sql`) from your local project in a text editor.
3.  **Copy and Paste:** Copy the entire content of the SQL file.
4.  **Execute in SQL Editor:** Paste the content into the Supabase SQL Editor and click **"Run"**.
5.  **Repeat:** Repeat steps 2-4 for each subsequent SQL migration file in chronological order until all migrations have been applied.

### Important Considerations

-   **Idempotency:** Drizzle migrations are generally designed to be idempotent, meaning they can be run multiple times without causing issues. However, it's best practice to apply them only once per database environment.
-   **Schema Evolution:** This manual process is suitable for initial deployment. For ongoing development and schema changes, consider integrating Drizzle ORM's migration commands into your CI/CD pipeline for automated application of new migrations.
-   **Backup:** Always perform a database backup before applying any schema changes in a production environment.
