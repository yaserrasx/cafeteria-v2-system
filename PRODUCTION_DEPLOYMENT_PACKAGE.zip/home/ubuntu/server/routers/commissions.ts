/**
 * Commission Router
 * Handles commission calculations, distributions, and balance management
 */

import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  getMarketerBalance,
  getOrCreateMarketerBalance,
  getCommissionDistributions,
  transitionCommissionsToAvailable,
  isCommissionExpired,
  createCafeteriaMarketerRelationship,
  createCommissionDistribution,
} from "../db";
import {
  calculateCommissionAmount,
  calculateCommissionDistributions,
  getCommissionStatusSummary,
  calculateTotalCommission,
  getCommissionHistorySummary,
  calculateCommissionExpiryDate,
  isCommissionActive,
} from "../utils/commissionEngine";
import { calculateCommissionExpiryDate as calcExpiry } from "../utils/commissionEngine";

export const commissionsRouter = router({
  /**
   * Get marketer's commission balance
   */
  getBalance: protectedProcedure
    .input(z.object({ marketerId: z.string() }))
    .query(async ({ input }) => {
      const balance = await getMarketerBalance(input.marketerId);

      if (!balance) {
        return {
          pendingBalance: 0,
          availableBalance: 0,
          totalWithdrawn: 0,
          totalEarned: 0,
          canWithdraw: false,
        };
      }

      const pending = Number(balance.pendingBalance) || 0;
      const available = Number(balance.availableBalance) || 0;
      const withdrawn = Number(balance.totalWithdrawn) || 0;

      return getCommissionStatusSummary(pending, available, withdrawn);
    }),

  /**
   * Get commission distributions for a recharge
   */
  getDistributions: protectedProcedure
    .input(z.object({ rechargeRequestId: z.string() }))
    .query(async ({ input }) => {
      const distributions = await getCommissionDistributions(input.rechargeRequestId);

      return {
        total: distributions.length,
        distributions: distributions.map((d) => ({
          id: d.id,
          marketerId: d.marketerId,
          level: d.level,
          commissionAmount: Number(d.commissionAmount) || 0,
          status: d.status,
          createdAt: d.createdAt,
        })),
        totalAmount: calculateTotalCommission(
          distributions.map((d) => ({
            commissionAmount: Number(d.commissionAmount) || 0,
          }))
        ),
      };
    }),

  /**
   * Get commission history summary for a marketer
   */
  getHistorySummary: protectedProcedure
    .input(z.object({ marketerId: z.string() }))
    .query(async ({ input }) => {
      // TODO: Implement proper query to get all distributions for this marketer
      // For now, return empty summary
      const marketerDistributions: any[] = [];

      if (marketerDistributions.length === 0) {
        return {
          totalDistributions: 0,
          pendingCount: 0,
          availableCount: 0,
          withdrawnCount: 0,
          pendingAmount: 0,
          availableAmount: 0,
          withdrawnAmount: 0,
        };
      }

      return getCommissionHistorySummary(
        marketerDistributions.map((d) => ({
          status: d.status || "pending",
          commissionAmount: Number(d.commissionAmount) || 0,
        }))
      );
    }),

  /**
   * Transition pending commissions to available (called on next recharge)
   */
  transitionToAvailable: protectedProcedure
    .input(z.object({ marketerId: z.string() }))
    .mutation(async ({ input }) => {
      await transitionCommissionsToAvailable(input.marketerId);

      const balance = await getMarketerBalance(input.marketerId);

      return {
        success: true,
        newBalance: {
          pendingBalance: Number(balance?.pendingBalance) || 0,
          availableBalance: Number(balance?.availableBalance) || 0,
        },
      };
    }),

  /**
   * Check if commission is still active (not expired)
   */
  isCommissionActive: protectedProcedure
    .input(
      z.object({
        cafeteriaId: z.string(),
        marketerId: z.string(),
      })
    )
    .query(async ({ input }) => {
      const isExpired = await isCommissionExpired(input.cafeteriaId, input.marketerId);
      return {
        isActive: !isExpired,
        isExpired,
      };
    }),

  /**
   * Get commission configuration for a marketer
   * (This would fetch from commissionConfigs table)
   */
  getConfig: protectedProcedure
    .input(z.object({ marketerId: z.string() }))
    .query(async ({ input }) => {
      // TODO: Implement after commissionConfigs router is created
      return {
        marketerId: input.marketerId,
        rate: 0,
        expiryOverrideMonths: null,
      };
    }),

  /**
   * Calculate commission for a recharge amount
   */
  calculateForRecharge: protectedProcedure
    .input(
      z.object({
        rechargeAmount: z.number().positive(),
        commissionRate: z.number().min(0).max(100),
      })
    )
    .query(({ input }) => {
      const commission = calculateCommissionAmount(input.rechargeAmount, input.commissionRate);

      return {
        rechargeAmount: input.rechargeAmount,
        commissionRate: input.commissionRate,
        commissionAmount: commission,
        percentage: `${input.commissionRate}%`,
      };
    }),

  /**
   * Validate commission expiry date
   */
  validateExpiryDate: protectedProcedure
    .input(
      z.object({
        startDate: z.date(),
        lifetimeMonths: z.number().positive(),
      })
    )
    .query(({ input }) => {
      const expiryDate = calcExpiry(input.startDate, input.lifetimeMonths);
      const isActive = isCommissionActive(expiryDate);

      return {
        startDate: input.startDate,
        lifetimeMonths: input.lifetimeMonths,
        expiryDate,
        isActive,
        daysRemaining: Math.ceil(
          (expiryDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
        ),
      };
    }),

  /**
   * Get commission summary for dashboard
   */
  getDashboardSummary: protectedProcedure
    .input(z.object({ marketerId: z.string() }))
    .query(async ({ input }) => {
      const balance = await getOrCreateMarketerBalance(input.marketerId);

      const pending = Number(balance.pendingBalance) || 0;
      const available = Number(balance.availableBalance) || 0;
      const withdrawn = Number(balance.totalWithdrawn) || 0;

      return {
        pending,
        available,
        withdrawn,
        total: pending + available + withdrawn,
        canWithdraw: available > 0,
        lastUpdated: balance.lastUpdated,
      };
    }),
});
