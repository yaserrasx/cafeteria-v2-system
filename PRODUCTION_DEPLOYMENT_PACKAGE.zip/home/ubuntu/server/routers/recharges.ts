/**
 * Recharge Router
 * Handles recharge requests, approval workflow, and commission distribution
 */

import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { nanoid } from "nanoid";
import { eq, and } from "drizzle-orm";
import { getDb } from "../db";
import {
  rechargeRequests,
  cafeterias,
  ledgerEntries,
  marketerBalances,
  commissionDistributions,
} from "../../drizzle/schema";
import { shouldGenerateCommissions } from "../utils/freeOperationEngine";

export const rechargesRouter = router({
  /**
   * Create a recharge request
   */
  createRequest: protectedProcedure
    .input(
      z.object({
        cafeteriaId: z.string(),
        amount: z.number().positive(),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const id = nanoid();
      const now = new Date();

      await db.insert(rechargeRequests).values({
        id,
        cafeteriaId: input.cafeteriaId,
        amount: String(input.amount),
        imageUrl: input.imageUrl,
        status: "pending",
        commissionCalculated: false,
        createdAt: now,
      });

      // Create ledger entry for recharge request
      await db.insert(ledgerEntries).values({
        id: nanoid(),
        type: "recharge_request",
        ledgerType: "points_credit",
        description: `Recharge request for ${input.amount} points`,
        cafeteriaId: input.cafeteriaId,
        amount: String(input.amount),
        refId: id,
        createdAt: now,
      });

      return {
        id,
        status: "pending",
        createdAt: now,
      };
    }),

  /**
   * Get recharge requests for a cafeteria
   */
  getRequests: protectedProcedure
    .input(
      z.object({
        cafeteriaId: z.string(),
        status: z.enum(["pending", "approved", "rejected"]).optional(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const requests = await db
        .select()
        .from(rechargeRequests)
        .where(
          input.status
            ? and(
                eq(rechargeRequests.cafeteriaId, input.cafeteriaId),
                eq(rechargeRequests.status, input.status)
              )
            : eq(rechargeRequests.cafeteriaId, input.cafeteriaId)
        );

      return requests.map((r) => ({
        id: r.id,
        cafeteriaId: r.cafeteriaId,
        amount: Number(r.amount) || 0,
        imageUrl: r.imageUrl,
        status: r.status,
        processedAt: r.processedAt,
        processedBy: r.processedBy,
        notes: r.notes,
        commissionCalculated: r.commissionCalculated,
        createdAt: r.createdAt,
      }));
    }),

  /**
   * Get pending recharge requests (admin view)
   */
  getPendingRequests: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const requests = await db
      .select()
      .from(rechargeRequests)
      .where(eq(rechargeRequests.status, "pending"));

    return requests.map((r) => ({
      id: r.id,
      cafeteriaId: r.cafeteriaId,
      amount: Number(r.amount) || 0,
      imageUrl: r.imageUrl,
      status: r.status,
      createdAt: r.createdAt,
    }));
  }),

  /**
   * Approve a recharge request
   */
  approveRequest: protectedProcedure
    .input(
      z.object({
        rechargeRequestId: z.string(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get the recharge request
      const requests = await db
        .select()
        .from(rechargeRequests)
        .where(eq(rechargeRequests.id, input.rechargeRequestId));

      if (requests.length === 0) {
        throw new Error("Recharge request not found");
      }

      const request = requests[0];
      const amount = Number(request.amount) || 0;

      // Get cafeteria details
      const cafeterias_result = await db
        .select()
        .from(cafeterias)
        .where(eq(cafeterias.id, request.cafeteriaId));

      if (cafeterias_result.length === 0) {
        throw new Error("Cafeteria not found");
      }

      const cafeteria = cafeterias_result[0];

      // Update recharge request status
      const now = new Date();
      await db
        .update(rechargeRequests)
        .set({
          status: "approved",
          processedAt: now,
          processedBy: ctx.user?.name || "admin",
          notes: input.notes,
          pointsAddedToBalance: String(amount),
        })
        .where(eq(rechargeRequests.id, input.rechargeRequestId));

      // Update cafeteria points balance
      const currentBalance = Number(cafeteria.pointsBalance) || 0;
      await db
        .update(cafeterias)
        .set({
          pointsBalance: String(currentBalance + amount),
        })
        .where(eq(cafeterias.id, request.cafeteriaId));

      // Create ledger entry for approval
      await db.insert(ledgerEntries).values({
        id: nanoid(),
        type: "recharge_approved",
        ledgerType: "points_credit",
        description: `Recharge approved: ${amount} points added`,
        cafeteriaId: request.cafeteriaId,
        amount: String(amount),
        refId: input.rechargeRequestId,
        createdAt: now,
      });

      return {
        success: true,
        rechargeId: input.rechargeRequestId,
        pointsAdded: amount,
        newBalance: currentBalance + amount,
      };
    }),

  /**
   * Reject a recharge request
   */
  rejectRequest: protectedProcedure
    .input(
      z.object({
        rechargeRequestId: z.string(),
        reason: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const now = new Date();

      await db
        .update(rechargeRequests)
        .set({
          status: "rejected",
          processedAt: now,
          processedBy: ctx.user?.name || "admin",
          notes: input.reason,
        })
        .where(eq(rechargeRequests.id, input.rechargeRequestId));

      // Create ledger entry for rejection
      const request = await db
        .select()
        .from(rechargeRequests)
        .where(eq(rechargeRequests.id, input.rechargeRequestId));

      if (request.length > 0) {
        await db.insert(ledgerEntries).values({
          id: nanoid(),
          type: "recharge_rejected",
          ledgerType: "points_deduction",
          description: `Recharge rejected: ${input.reason}`,
          cafeteriaId: request[0].cafeteriaId,
          refId: input.rechargeRequestId,
          createdAt: now,
        });
      }

      return {
        success: true,
        rechargeId: input.rechargeRequestId,
      };
    }),

  /**
   * Get recharge statistics
   */
  getStatistics: protectedProcedure
    .input(z.object({ cafeteriaId: z.string().optional() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      let allRequests: any[] = [];
      if (input.cafeteriaId) {
        allRequests = await db
          .select()
          .from(rechargeRequests)
          .where(eq(rechargeRequests.cafeteriaId, input.cafeteriaId));
      } else {
        allRequests = await db.select().from(rechargeRequests);
      }
      const requests = allRequests;

      const stats = {
        total: requests.length,
        pending: 0,
        approved: 0,
        rejected: 0,
        totalAmount: 0,
        approvedAmount: 0,
      };

      requests.forEach((r) => {
        const amount = Number(r.amount) || 0;

        if (r.status === "pending") stats.pending++;
        else if (r.status === "approved") {
          stats.approved++;
          stats.approvedAmount += amount;
        } else if (r.status === "rejected") stats.rejected++;

        stats.totalAmount += amount;
      });

      return stats;
    }),

  /**
   * Get recharge history with commission details
   */
  getHistory: protectedProcedure
    .input(z.object({ cafeteriaId: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const requests = await db
        .select()
        .from(rechargeRequests)
        .where(eq(rechargeRequests.cafeteriaId, input.cafeteriaId));

      const history = [];

      for (const request of requests) {
        const distributions = await db
          .select()
          .from(commissionDistributions)
          .where(eq(commissionDistributions.rechargeRequestId, request.id));

        history.push({
          id: request.id,
          amount: Number(request.amount) || 0,
          status: request.status,
          createdAt: request.createdAt,
          processedAt: request.processedAt,
          commissionDistributions: distributions.length,
          totalCommissionAmount: distributions.reduce(
            (sum, d) => sum + (Number(d.commissionAmount) || 0),
            0
          ),
        });
      }

      return history.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    }),

  /**
   * Get cafeteria details including points balance
   */
  getCafeteriaDetails: protectedProcedure
    .input(z.object({ cafeteriaId: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db
        .select()
        .from(cafeterias)
        .where(eq(cafeterias.id, input.cafeteriaId))
        .limit(1);

      if (result.length === 0) {
        throw new Error("Cafeteria not found");
      }

      const cafeteria = result[0];

      return {
        id: cafeteria.id,
        name: cafeteria.name,
        location: cafeteria.location,
        pointsBalance: cafeteria.pointsBalance,
        graceMode: cafeteria.graceMode,
        currency: cafeteria.currency,
        createdAt: cafeteria.createdAt,
      };
    }),
});
