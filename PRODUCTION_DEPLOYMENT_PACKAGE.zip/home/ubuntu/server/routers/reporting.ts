import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { nanoid } from "nanoid";
import { eq, and, gte, lte } from "drizzle-orm";
import { getDb } from "../db";
import {
  cafeteriaReports,
  orders,
  orderItems,
  shifts,
  cafeterias,
} from "../../drizzle/schema";
import {
  generateCafeteriaReport,
  calculateTotalSales,
  calculateTotalItemsSold,
  calculateAverageOrderValue,
  getTopSellingItems,
  getTopPerformingStaff,
  calculatePeakHours,
  compareReports,
  validateReportParameters,
} from "../utils/reportingEngine";

export const reportingRouter = router({
  generateDailyReport: protectedProcedure
    .input(
      z.object({
        cafeteriaId: z.string(),
        reportDate: z.date(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const startOfDay = new Date(input.reportDate);
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date(input.reportDate);
      endOfDay.setHours(23, 59, 59, 999);

      const ordersData = await db
        .select()
        .from(orders)
        .where(
          and(
            eq(orders.cafeteriaId, input.cafeteriaId),
            gte(orders.closedAt, startOfDay),
            lte(orders.closedAt, endOfDay),
            eq(orders.status, "closed")
          )
        );

      const itemsData = await db
        .select()
        .from(orderItems)
        .where(
          and(
            eq(orderItems.status, "served"),
            gte(orderItems.servedAt, startOfDay),
            lte(orderItems.servedAt, endOfDay)
          )
        );

      const shiftsData = await db
        .select()
        .from(shifts)
        .where(
          and(
            eq(shifts.cafeteriaId, input.cafeteriaId),
            gte(shifts.startTime, startOfDay),
            lte(shifts.startTime, endOfDay)
          )
        );

      const cafeteriaData = await db
        .select()
        .from(cafeterias)
        .where(eq(cafeterias.id, input.cafeteriaId));

      const totalSales = calculateTotalSales(ordersData);
      const totalOrders = ordersData.length;
      const totalItemsSold = calculateTotalItemsSold(itemsData);
      const totalPointsDeducted = ordersData.reduce(
        (sum, order) => sum + (Number(order.pointsConsumed) || 0),
        0
      );
      const averageOrderValue = calculateAverageOrderValue(totalSales, totalOrders);

      const reportId = nanoid();
      const now = new Date();

      await db.insert(cafeteriaReports).values({
        id: reportId,
        cafeteriaId: input.cafeteriaId,
        reportType: "daily",
        reportDate: input.reportDate,
        totalSales: String(totalSales),
        totalOrders,
        totalItemsSold,
        totalPointsDeducted: String(totalPointsDeducted),
        averageOrderValue: String(averageOrderValue),
        generatedAt: now,
      });

      return {
        id: reportId,
        cafeteriaId: input.cafeteriaId,
        reportType: "daily",
        reportDate: input.reportDate,
        totalSales,
        totalOrders,
        totalItemsSold,
        totalPointsDeducted,
        averageOrderValue,
        topItems: getTopSellingItems(itemsData, 5),
        topStaff: getTopPerformingStaff(shiftsData, 5),
        peakHours: calculatePeakHours(ordersData),
      };
    }),

  getReport: protectedProcedure
    .input(z.object({ reportId: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const reportResult = await db
        .select()
        .from(cafeteriaReports)
        .where(eq(cafeteriaReports.id, input.reportId));

      if (reportResult.length === 0) {
        throw new Error("Report not found");
      }

      const report = reportResult[0];

      return {
        id: report.id,
        cafeteriaId: report.cafeteriaId,
        reportType: report.reportType,
        reportDate: report.reportDate,
        totalSales: Number(report.totalSales) || 0,
        totalOrders: report.totalOrders || 0,
        totalItemsSold: report.totalItemsSold || 0,
        totalPointsDeducted: Number(report.totalPointsDeducted) || 0,
        averageOrderValue: Number(report.averageOrderValue) || 0,
        generatedAt: report.generatedAt,
      };
    }),

  getCafeteriaReports: protectedProcedure
    .input(
      z.object({
        cafeteriaId: z.string(),
        reportType: z.enum(["daily", "weekly", "monthly"]).optional(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const conditions = [eq(cafeteriaReports.cafeteriaId, input.cafeteriaId)];

      if (input.reportType) {
        conditions.push(eq(cafeteriaReports.reportType, input.reportType));
      }

      if (input.startDate) {
        conditions.push(gte(cafeteriaReports.reportDate, input.startDate));
      }

      if (input.endDate) {
        conditions.push(lte(cafeteriaReports.reportDate, input.endDate));
      }

      const result = await db
        .select()
        .from(cafeteriaReports)
        .where(and(...conditions));

      return result.map((report) => ({
        id: report.id,
        reportType: report.reportType,
        reportDate: report.reportDate,
        totalSales: Number(report.totalSales) || 0,
        totalOrders: report.totalOrders || 0,
        totalItemsSold: report.totalItemsSold || 0,
        totalPointsDeducted: Number(report.totalPointsDeducted) || 0,
        averageOrderValue: Number(report.averageOrderValue) || 0,
        generatedAt: report.generatedAt,
      }));
    }),

  getSalesComparison: protectedProcedure
    .input(
      z.object({
        cafeteriaId: z.string(),
        startDate: z.date(),
        endDate: z.date(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const reports = await db
        .select()
        .from(cafeteriaReports)
        .where(
          and(
            eq(cafeteriaReports.cafeteriaId, input.cafeteriaId),
            gte(cafeteriaReports.reportDate, input.startDate),
            lte(cafeteriaReports.reportDate, input.endDate)
          )
        );

      let totalSales = 0;
      let totalOrders = 0;
      let totalItemsSold = 0;
      let totalPointsDeducted = 0;

      reports.forEach((report) => {
        totalSales += Number(report.totalSales) || 0;
        totalOrders += report.totalOrders || 0;
        totalItemsSold += report.totalItemsSold || 0;
        totalPointsDeducted += Number(report.totalPointsDeducted) || 0;
      });

      const averageOrderValue = calculateAverageOrderValue(totalSales, totalOrders);

      return {
        cafeteriaId: input.cafeteriaId,
        startDate: input.startDate,
        endDate: input.endDate,
        reportCount: reports.length,
        totalSales,
        totalOrders,
        totalItemsSold,
        totalPointsDeducted,
        averageOrderValue,
        averageSalesPerDay: reports.length > 0 ? totalSales / reports.length : 0,
        averageOrdersPerDay: reports.length > 0 ? totalOrders / reports.length : 0,
      };
    }),

  getTopItemsReport: protectedProcedure
    .input(
      z.object({
        cafeteriaId: z.string(),
        startDate: z.date(),
        endDate: z.date(),
        limit: z.number().default(10),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const itemsData = await db
        .select()
        .from(orderItems)
        .where(
          and(
            gte(orderItems.servedAt, input.startDate),
            lte(orderItems.servedAt, input.endDate),
            eq(orderItems.status, "served")
          )
        );

      const topItems = getTopSellingItems(itemsData, input.limit);

      return {
        cafeteriaId: input.cafeteriaId,
        startDate: input.startDate,
        endDate: input.endDate,
        topItems,
      };
    }),

  getTopStaffReport: protectedProcedure
    .input(
      z.object({
        cafeteriaId: z.string(),
        startDate: z.date(),
        endDate: z.date(),
        limit: z.number().default(10),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const shiftsData = await db
        .select()
        .from(shifts)
        .where(
          and(
            eq(shifts.cafeteriaId, input.cafeteriaId),
            gte(shifts.startTime, input.startDate),
            lte(shifts.startTime, input.endDate)
          )
        );

      const topStaff = getTopPerformingStaff(shiftsData, input.limit);

      return {
        cafeteriaId: input.cafeteriaId,
        startDate: input.startDate,
        endDate: input.endDate,
        topStaff,
      };
    }),
});
