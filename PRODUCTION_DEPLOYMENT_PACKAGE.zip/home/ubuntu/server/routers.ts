import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { ordersRouter } from "./routers/orders";
import { shiftsRouter } from "./routers/shifts";
import { reportingRouter } from "./routers/reporting";
import { menuRouter } from "./routers/menu";
import { tablesRouter } from "./routers/tables";
import { rechargesRouter } from "./routers/recharges";
import { staffRouter } from "./routers/staff";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  orders: ordersRouter,
  shifts: shiftsRouter,
  reporting: reportingRouter,
  menu: menuRouter,
  tables: tablesRouter,
  cafeterias: rechargesRouter,
  staff: staffRouter,
});

export type AppRouter = typeof appRouter;
