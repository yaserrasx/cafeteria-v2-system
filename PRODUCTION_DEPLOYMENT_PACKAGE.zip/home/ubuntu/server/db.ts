import { drizzle } from "drizzle-orm/mysql2";
import { eq, and, gte, lte, desc } from "drizzle-orm";
import {
  InsertUser,
  users,
  marketers,
  cafeterias,
  rechargeRequests,
  ledgerEntries,
  marketerBalances,
  commissionDistributions,
  cafeteriaMarketerRelationships,
  freeOperationPeriods,
  sections,
  cafeteriaTables,
  cafeteriaStaff,
  staffSectionAssignments,
  staffCategoryAssignments,
  menuCategories,
  menuItems,
  orders,
  systemConfigs,
  type MarketerBalance,
  type CommissionDistribution,
  type FreeOperationPeriod,
  type Cafeteria,
  type Marketer,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============================================================================
// MARKETER BALANCE OPERATIONS
// ============================================================================

export async function getOrCreateMarketerBalance(marketerId: string): Promise<MarketerBalance> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(marketerBalances)
    .where(eq(marketerBalances.marketerId, marketerId))
    .limit(1);

  if (existing.length > 0) {
    return existing[0];
  }

  // Create new balance record
  const id = require("nanoid").nanoid();
  await db.insert(marketerBalances).values({
    id,
    marketerId,
    pendingBalance: "0",
    availableBalance: "0",
    totalWithdrawn: "0",
  });

  return {
    id,
    marketerId,
    pendingBalance: "0",
    availableBalance: "0",
    totalWithdrawn: "0",
    lastUpdated: new Date(),
  } as MarketerBalance;
}

export async function getMarketerBalance(marketerId: string): Promise<MarketerBalance | null> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(marketerBalances)
    .where(eq(marketerBalances.marketerId, marketerId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function updateMarketerBalance(
  marketerId: string,
  pendingDelta: number,
  availableDelta: number
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const balance = await getOrCreateMarketerBalance(marketerId);
  const pendingNum = Number(balance.pendingBalance) || 0;
  const availableNum = Number(balance.availableBalance) || 0;

  await db
    .update(marketerBalances)
    .set({
      pendingBalance: String(Math.max(0, pendingNum + pendingDelta)),
      availableBalance: String(Math.max(0, availableNum + availableDelta)),
      lastUpdated: new Date(),
    })
    .where(eq(marketerBalances.marketerId, marketerId));
}

// ============================================================================
// COMMISSION DISTRIBUTION OPERATIONS
// ============================================================================

export async function createCommissionDistribution(
  rechargeRequestId: string,
  marketerId: string,
  level: number,
  commissionAmount: string | number
): Promise<CommissionDistribution> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const id = require("nanoid").nanoid();
  const now = new Date();

  await db.insert(commissionDistributions).values({
    id,
    rechargeRequestId,
    marketerId,
    level,
    commissionAmount: String(commissionAmount),
    status: "pending",
    createdAt: now,
  });

  return {
    id,
    rechargeRequestId,
    marketerId,
    level,
    commissionAmount: String(commissionAmount),
    status: "pending" as const,
    createdAt: now,
  } as CommissionDistribution;
}

export async function getCommissionDistributions(
  rechargeRequestId: string
): Promise<CommissionDistribution[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(commissionDistributions)
    .where(eq(commissionDistributions.rechargeRequestId, rechargeRequestId));
}

export async function transitionCommissionsToAvailable(marketerId: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get all pending commissions for this marketer
  const pendingCommissions = await db
    .select()
    .from(commissionDistributions)
    .where(
      and(
        eq(commissionDistributions.marketerId, marketerId),
        eq(commissionDistributions.status, "pending")
      )
    );

    // Calculate total pending amount
    const totalPending = pendingCommissions.reduce((sum, c) => sum + (Number(c.commissionAmount) || 0), 0);

  if (totalPending > 0) {
    // Update all pending to available
    for (const commission of pendingCommissions) {
      await db
        .update(commissionDistributions)
        .set({ status: "available" })
        .where(eq(commissionDistributions.id, commission.id));
    }

    // Update marketer balance
    const balance = await getOrCreateMarketerBalance(marketerId);
    const pendingNum = Number(balance.pendingBalance) || 0;
    const availableNum = Number(balance.availableBalance) || 0;
    await db
      .update(marketerBalances)
      .set({
        pendingBalance: String(Math.max(0, pendingNum - totalPending)),
        availableBalance: String(availableNum + totalPending),
        lastUpdated: new Date(),
      })
      .where(eq(marketerBalances.marketerId, marketerId));
  }
}

// ============================================================================
// CAFETERIA MARKETER RELATIONSHIP OPERATIONS
// ============================================================================

export async function createCafeteriaMarketerRelationship(
  cafeteriaId: string,
  marketerId: string,
  commissionExpiryDate: Date
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const id = require("nanoid").nanoid();

  await db.insert(cafeteriaMarketerRelationships).values({
    id,
    cafeteriaId,
    marketerId,
    commissionStartDate: new Date(),
    commissionExpiryDate,
    isExpired: false,
  });
}

export async function isCommissionExpired(
  cafeteriaId: string,
  marketerId: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(cafeteriaMarketerRelationships)
    .where(
      and(
        eq(cafeteriaMarketerRelationships.cafeteriaId, cafeteriaId),
        eq(cafeteriaMarketerRelationships.marketerId, marketerId)
      )
    )
    .limit(1);

  if (result.length === 0) return false;

  const relationship = result[0];
  return relationship.isExpired || new Date() > relationship.commissionExpiryDate;
}

// ============================================================================
// FREE OPERATION PERIOD OPERATIONS
// ============================================================================

export async function createFreeOperationPeriod(
  cafeteriaId: string,
  periodType: "global_first_time" | "special_grant",
  startDate: Date,
  endDate: Date,
  reason?: string,
  createdBy?: string
): Promise<FreeOperationPeriod> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const id = require("nanoid").nanoid();
  const now = new Date();

  await db.insert(freeOperationPeriods).values({
    id,
    cafeteriaId,
    periodType,
    startDate,
    endDate,
    reason: reason || null,
    createdBy: createdBy || null,
    createdAt: now,
  });

  return {
    id,
    cafeteriaId,
    periodType,
    startDate,
    endDate,
    reason: reason ?? undefined,
    createdBy: createdBy ?? undefined,
    createdAt: now,
  } as FreeOperationPeriod;
}

export async function getActiveFreeOperationPeriod(
  cafeteriaId: string
): Promise<FreeOperationPeriod | null> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();

  const result = await db
    .select()
    .from(freeOperationPeriods)
    .where(
      and(
        eq(freeOperationPeriods.cafeteriaId, cafeteriaId),
        lte(freeOperationPeriods.startDate, now),
        gte(freeOperationPeriods.endDate, now)
      )
    )
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function isInFreeOperationPeriod(cafeteriaId: string): Promise<boolean> {
  const period = await getActiveFreeOperationPeriod(cafeteriaId);
  return period !== null;
}

// ============================================================================
// STAFF PERMISSION OPERATIONS
// ============================================================================

export async function grantStaffLoginPermission(
  staffId: string,
  grantedBy: string
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(cafeteriaStaff)
    .set({
      canLogin: true,
      loginPermissionGrantedAt: new Date(),
      loginPermissionGrantedBy: grantedBy,
    })
    .where(eq(cafeteriaStaff.id, staffId));
}

export async function revokeStaffLoginPermission(staffId: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(cafeteriaStaff)
    .set({
      canLogin: false,
    })
    .where(eq(cafeteriaStaff.id, staffId));
}

export async function canStaffLogin(staffId: string): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(cafeteriaStaff)
    .where(eq(cafeteriaStaff.id, staffId))
    .limit(1);

  return result.length > 0 && result[0].canLogin === true;
}

// ============================================================================
// SECTION OPERATIONS
// ============================================================================

export async function createSection(
  cafeteriaId: string,
  name: string,
  displayOrder: number = 0
): Promise<string> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const id = require("nanoid").nanoid();

  await db.insert(sections).values({
    id,
    cafeteriaId,
    name,
    displayOrder,
  });

  return id;
}

export async function getSectionsByCafeteria(cafeteriaId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(sections)
    .where(eq(sections.cafeteriaId, cafeteriaId))
    .orderBy(sections.displayOrder);
}

// ============================================================================
// STAFF SECTION ASSIGNMENT OPERATIONS
// ============================================================================

export async function assignStaffToSection(staffId: string, sectionId: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const id = require("nanoid").nanoid();

  await db.insert(staffSectionAssignments).values({
    id,
    staffId,
    sectionId,
  });
}

export async function getStaffSectionAssignments(staffId: string): Promise<string[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(staffSectionAssignments)
    .where(eq(staffSectionAssignments.staffId, staffId));

  return result.map((r) => r.sectionId);
}

// ============================================================================
// STAFF CATEGORY ASSIGNMENT OPERATIONS
// ============================================================================

export async function assignStaffToCategory(staffId: string, categoryId: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const id = require("nanoid").nanoid();

  await db.insert(staffCategoryAssignments).values({
    id,
    staffId,
    categoryId,
  });
}

export async function getStaffCategoryAssignments(staffId: string): Promise<string[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(staffCategoryAssignments)
    .where(eq(staffCategoryAssignments.staffId, staffId));

  return result.map((r) => r.categoryId);
}

// TODO: add more feature queries as your schema grows.
