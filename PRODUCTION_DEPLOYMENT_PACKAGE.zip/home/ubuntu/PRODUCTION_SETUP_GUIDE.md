# CAFETERIA V2 - Production Setup Guide

## Overview

This guide provides step-by-step instructions for deploying the CAFETERIA V2 system to a production environment. It covers setting up the database with Supabase, configuring environment variables, deploying the application to Vercel, and verifying the system's health post-deployment.

## 1. Supabase Project Creation and Database Setup

Supabase is used as the managed PostgreSQL database for CAFETERIA V2 in production. Follow these steps to set up your Supabase project and apply the database schema.

### 1.1. Create a New Supabase Project

1.  Navigate to the [Supabase website](https://supabase.com/) and log in to your account.
2.  Click on **"New project"** to create a new project.
3.  Choose an organization, provide a **project name** (e.g., `cafeteria-v2-prod`), set a strong **database password**, and select a **region** that is geographically close to your users for optimal performance.
4.  Click **"Create new project"**.

### 1.2. Retrieve Database Connection String

Once your project is created:

1.  In your Supabase project dashboard, navigate to **"Project Settings"** (gear icon).
2.  Go to **"Database"** in the sidebar.
3.  Under the **"Connection string"** section, find the connection string for your database. Copy the `URI` (e.g., `postgresql://postgres:[YOUR-PASSWORD]@[YOUR-HOST].supabase.co:5432/postgres`). This will be used as your `DATABASE_URL` environment variable.

### 1.3. Apply Database Schema (Migrations)

CAFETERIA V2 uses Drizzle ORM for schema management. Since Supabase uses PostgreSQL, you'll need to ensure your Drizzle configuration is set for PostgreSQL and then apply the migrations.

1.  **Verify Drizzle Configuration:** Ensure your `drizzle.config.ts` (or equivalent) is configured for PostgreSQL. The existing schema files in `drizzle/migrations` are generated for MySQL, so you will need to generate new migrations for PostgreSQL or manually adapt the schema.
    *   **Note:** For this project, the `drizzle/schema.ts` defines the schema, and the `.sql` files in `drizzle/` are the migration history. You will need to manually apply the schema defined in `drizzle/schema.ts` to your Supabase PostgreSQL database. You can do this by converting the Drizzle schema to raw SQL or by using Drizzle's `push:pg` command if you reconfigure Drizzle for PostgreSQL.

    **Manual Schema Application (Recommended for initial setup):**
    *   Open the `drizzle/schema.ts` file.
    *   Manually translate the Drizzle schema definitions into PostgreSQL-compatible SQL `CREATE TABLE` statements.
    *   In your Supabase dashboard, navigate to **"SQL Editor"**.
    *   Paste and run your `CREATE TABLE` statements to apply the schema.

2.  **SQL Migration Execution Order:** The `.sql` files in the `drizzle/` directory represent the migration history. They should be applied in chronological order (e.g., `0000_...sql`, then `0001_...sql`, etc.). If you are manually applying the schema from `drizzle/schema.ts`, these migration files serve as a reference for the evolution of the schema.

## 2. Environment Variable Configuration

Environment variables are crucial for securing your application and connecting to external services. These must be set in your deployment platform (e.g., Vercel) and not committed to your repository.

### 2.1. Required Environment Variables

Create a `.env.example` file (or use the provided one) with the following structure. Replace placeholder values with your actual production secrets and configurations.

```env
# Database Configuration (Supabase PostgreSQL)
DATABASE_URL="postgresql://postgres:[YOUR-PASSWORD]@[YOUR-HOST].supabase.co:5432/postgres"

# Authentication (Google OAuth)
AUTH_SECRET="your_long_random_auth_secret_key" # Generate a strong, random string
GOOGLE_CLIENT_ID="your_google_oauth_client_id"
GOOGLE_CLIENT_SECRET="your_google_oauth_client_secret"

# S3 Storage (for image uploads, e.g., AWS S3)
AWS_ACCESS_KEY_ID="your_aws_access_key_id"
AWS_SECRET_ACCESS_KEY="your_aws_secret_access_key"
AWS_REGION="your_aws_region" # e.g., us-east-1
AWS_S3_BUCKET_NAME="your_s3_bucket_name"

# Owner's OpenID (for initial admin access)
OWNER_OPEN_ID="the_openid_of_the_initial_admin_user"

# Other Services (if applicable, e.g., OpenAI)
OPENAI_API_KEY="your_openai_api_key"

# Vercel Specific (if deploying to Vercel)
NEXT_PUBLIC_VERCEL_URL="https://your-project-name.vercel.app" # Your Vercel deployment URL
```

### 2.2. Initial Admin Creation Instructions

After deploying the application and setting up the database, you will need to create an initial admin user. This is typically done by setting the `OWNER_OPEN_ID` environment variable.

1.  **Log in with Google:** Access your deployed application and log in using the Google account you wish to designate as the initial admin.
2.  **Retrieve OpenID:** After logging in, you can typically find your OpenID in the application's session or user profile data (e.g., in `ctx.user.openId` in the backend context). Alternatively, you can inspect network requests during login to find the `sub` claim in the JWT token, which is usually the OpenID.
3.  **Set `OWNER_OPEN_ID`:** Add this OpenID to your Vercel environment variables as `OWNER_OPEN_ID`.
4.  **Re-deploy:** Trigger a re-deployment on Vercel. Upon the next login with that Google account, the user will be assigned the `admin` role.

## 3. Vercel Deployment Configuration

CAFETERIA V2 is optimized for deployment on Vercel. Ensure your Vercel project settings are correctly configured.

### 3.1. Link Project to Vercel

If you haven't already, link your local project to Vercel:

```bash
vercel link
```

Follow the prompts to connect to your Vercel account and link to a new or existing project.

### 3.2. Configure Environment Variables on Vercel

1.  Go to your Vercel project dashboard.
2.  Navigate to **"Settings" > "Environment Variables"**.
3.  Add all the environment variables listed in Section 2.1. Ensure they are configured for the `Production`, `Preview`, and `Development` environments as appropriate.

### 3.3. Production Build Commands

Vercel typically auto-detects the build commands for Vite/React projects. However, if manual configuration is needed:

-   **Build Command:** `pnpm build` (or `npm run build`)
-   **Output Directory:** `dist` (or `build`)

### 3.4. Deploy to Vercel

Deploy your application using the Vercel CLI or by pushing changes to your Git repository if integrated:

```bash
vercel deploy --prod
```

This command will build and deploy your application to production.

## 4. Verifying System Health Post-Deployment

After successful deployment, perform the following checks to ensure the system is operating correctly.

### 4.1. Access Application

1.  Open your deployed application URL in a web browser.
2.  Attempt to log in using your designated admin Google account.

### 4.2. Database Connectivity

1.  Verify that the application can connect to the Supabase database. Check the Vercel deployment logs for any database connection errors.
2.  As an admin user, try to perform an action that interacts with the database (e.g., create a new cafeteria, add a staff member). Confirm that data is persisted.

### 4.3. API Endpoint Verification

1.  Use your browser's developer tools or a tool like Postman/Insomnia to test a few key API endpoints (e.g., `auth.me`, `cafeterias.getCafeteriaDetails`). Ensure they return expected data and status codes.
2.  Verify that role-based access control is functioning by attempting to access restricted endpoints with a non-admin user (if available).

### 4.4. Core Feature Validation

1.  **Recharge Workflow:** As a Cafe Admin, create a recharge request. As an Owner/Admin, approve it and verify that the cafeteria's points balance updates and commission distributions are created.
2.  **Order Lifecycle:** As a Waiter, create an order, add items, send items to the kitchen. As a Chef, update item statuses. As a Waiter, close the order and verify points deduction.
3.  **Dashboards:** Navigate to each dashboard (Manager, Waiter, Chef, Reporting) and ensure data is loading correctly and UI elements are interactive.

### 4.5. Logging and Monitoring

1.  Check Vercel's logs for your deployment to monitor for any runtime errors or warnings.
2.  Consider setting up external monitoring tools for continuous health checks and performance tracking.

By following these steps, you can ensure a smooth and successful production deployment of your CAFETERIA V2 system.
